name = input ("What is your name? ")
print (name)
color = input("What is your favorit color? ")
animal = input("What is ypur favorit anima? ")

print("{}, you like a {} {}!".format(name, color, animal))