firstString = "water"
secondString = "fall"
thirdString = firstString + secondString
print(thirdString)