myFruitList = ["apple", "banana", "cheery"]
print(myFruitList)
print (type(myFruitList))
print (myFruitList[0])
print (myFruitList[1])
print (myFruitList[2])

# Change a value in a list
myFruitList[2] = "orange"
print(myFruitList)