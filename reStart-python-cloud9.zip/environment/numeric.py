# print('Python has tree types numeric : int, fload, and complex')

myValue=True
print(myValue)
print(type(myValue))

print(str(myValue) + " is of the data type " + str(type(myValue)))
