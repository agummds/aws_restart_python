myFavoriteFruitDictionary = {
    "Akua" : "Apple",
    "Saanvi" : "Banana",
    "Paulo" : "Pineapple"
}

print(myFavoriteFruitDictionary)
print(type(myFavoriteFruitDictionary))

#Aaccessing a dictionary by name
print(myFavoriteFruitDictionary["Akua"])
print(myFavoriteFruitDictionary["Saanvi"])
print(myFavoriteFruitDictionary["Paulo"])
